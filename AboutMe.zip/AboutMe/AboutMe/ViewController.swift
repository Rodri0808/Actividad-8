//
//  ViewController.swift
//  AboutMe
//
//  Created by Alumno on 01/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

